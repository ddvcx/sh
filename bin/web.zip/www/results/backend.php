<?php
error_reporting(0);
@ini_set('zlib.output_compression', 'Off');
@ini_set('output_buffering', 'Off');
@ini_set('implicit_flush', 'On');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Encoding, Content-Type');
header('X-Content-Type-Options: nosniff');
$op = isset($_GET['op']) ? $_GET['op'] : 'empty';
if ($op === 'garbage') {
    header('Content-Type: application/octet-stream');
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="garbage.dat"');
    header('Expires: 0');
    $data = openssl_random_pseudo_bytes(1048576);
    $chunks = isset($_GET['ckSize']) ? intval($_GET['ckSize']) : 4; 
    if ($chunks < 1) $chunks = 1;
    if ($chunks > 100) $chunks = 100;
    for ($i = 0; $i < $chunks; $i++) {
        echo $data;
        flush();
    }
} else if ($op === 'getIP') {
    header('Content-Type: application/json');
    echo json_encode(['processedString' => $_SERVER['REMOTE_ADDR'], 'rawIspInfo' => '']);
} else {
    header('Content-Type: text/plain');
}
