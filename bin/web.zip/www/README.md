
chmod -R 0777 /etc/caddy/www

Note：
Caddy v2
	@X {
		path_regexp X ^/([a-zA-Z0-9_-]+)$
	}
	rewrite @X /index.php?note={re.X.1}

Caddy v1.0.5 秋水逸冰编译版
	rewrite {
		regexp ^/([a-zA-Z0-9_-]+)$
		to {uri} {uri}/ /index.php?note={1}
	}

If notepad is in the root directory:
location / {
    rewrite ^/([a-zA-Z0-9_-]+)$ /index.php?note=$1;
}

If notepad is in a subdirectory:
location ~* ^/notes/([a-zA-Z0-9_-]+)$ {
    try_files $uri /notes/index.php?note=$1;
}

WebDav：
    basicauth / 账号 密码
    webdav / {
        scope /home/
    }

## 更新日志
- 修复测速前端（index.html）无法调用 backend.php 的路径问题
- 清理并移除了失效的搜狐 IP 探测接口
- 优化 IP 探测逻辑，通过本地 backend.php 接口作为极速 fallback，提升了网络探测速度和稳定性
- 修复上传测速失败导致“速度表不会动”的问题：更正 Web Worker 内部的相对路径，降低单次上传载荷(Blob Size)限制防止路由器 413 错误，并增加跨域 CORS 响应头兼容性
- 彻底解决上传速度表不动的问题：摒弃 Worker 内部环境的不可靠相对路径解析，直接通过页面 URL 动态拼接绝对路径 (Absolute URL) 给到测速引擎，确保上下行请求始终能精准命中 API；同时解除默认的 `data_ul_max` 与 `data_dl_max` (30MB) 体积限制，防止因用户千兆网络导致测速在“缓冲宽限期（Grace Time）”内过早结束而未能渲染指针的情况。